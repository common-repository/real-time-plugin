(function () {
    //extending the String object to allow templating through supplant method
    if (typeof String.prototype.parseTemplate !== 'function') {
        String.prototype.parseTemplate = function (o) {
            return this.replace(/\[xRTML:([^\[\]]*)\]/g, function (a, b) {
                var r = o[b];
                return typeof r === 'string' ? r : a;
            });
        };
    }

    //Douglas Crockford's Walk the DOM
    function walkTheDOM(node, func) {
        func(node);
        node = node.firstChild;
        while (node) {
            walkTheDOM(node, func);
            node = node.nextSibling;
        }
    }
    //IE < 9 doesn't support ClassName
    if (!document.getElementsByClassName)
        document.getElementsByClassName = function (className) {
        var results = [];
        walkTheDOM(document.body, function (node) {
            var a, c = node.className, i;
            if (c) {
                a = c.split(' ');
                for (i = 0; i < a.length; i++) {
                    if (a[i] === className) {
                        results.push(node);
                        break;
                    }
                }
            }
        });
        return results;
    }

        function outerHtml(el, html) {
            if ('outerHTML' in el) {
                el.outerHTML = html;
            } else { // fallback para o Firefox
                console.log('outerHTML n�o suportado por este browser.');
                var temp = document.createElement('div');
                temp.innerHTML = html;
                while (temp.firstChild) {
                    el.parentNode.insertBefore(temp.firstChild, el);
                }
                el.parentNode.removeChild(el);
            }
        };

})();






















