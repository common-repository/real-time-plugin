(function(){
	function html5elm(elm) { return !!document.createElement(elm); }
	var myArray = ['header','nav','section','aside','article','hgroup','figure','figcaption','footer', 'time'];
	for (var i = 0; i < myArray.length; i++){ html5elm(myArray[i]); }
})();

jQuery(function(){	
	var plugins = jQuery('[realtime_index]');
	var parents = Array();
	jQuery(plugins).each(function(){
		var parent = jQuery(this).parent();		
		if(parents.indexOf(parent[0]) < 0){
			parents.push(parent[0]);
			var children = jQuery(parent).children();
			var orderedChildren = Array();			
			jQuery(children).filter('[realtime_index]').each(function(){
				orderedChildren[jQuery(this).attr('realtime_index') - 1] = jQuery(this);
				children.splice(jQuery(this).index());
			});
			var index = 0;
			jQuery(children).filter('*:[!realtime_index]').each(function(){
				var that = this;			
				var recurse = function(){
					if(orderedChildren[index]){
						index++;
						recurse();
					} else{
						orderedChildren[index] = jQuery(that);
						index++;
					}
				};
				recurse();
			});			
			for(var cont = 0; cont < orderedChildren.length; cont++){
				jQuery(parent).append(orderedChildren[cont]);
			}
		}		
	});
});

function createAlert(object) {
    var alertBox = document.createElement('div');
    alertBox.setAttribute('id', 'alertBox');
    var style = '';
    alertBox.setAttribute('style', style);
    alertBox.innerHTML = '<a style="" href="'+object.data.posturl+'">Novo Post<br />adicionado</a>';
    document.body.appendChild(alertBox);
    window.setTimeout(function () {document.body.removeChild(alertBox);}, 3000);
}


function createComment(object) {
	if(document.getElementById('nposts')){
		var nposts = document.getElementById('nposts').innerHTML != 'One' ? parseInt(document.getElementById('nposts').innerHTML) + 1 : 2;
		document.getElementById('nposts').innerHTML = nposts;
	}
	var html = object.data.htmlblock;	
	if(!object.data.postHasComments){
		document.getElementById('comments').innerHTML = html + document.getElementById('comments').innerHTML; 
	} else if(object.data.comment_parent == 0){
		document.getElementById('commentslist').innerHTML =  document.getElementById('commentslist').innerHTML + html;
	} else {
		if (!object.data.commentHasSiblings){
			var li = document.getElementById('li-comment-' + object.data.comment_parent);
			li.innerHTML = li.innerHTML + html;
		} else {			
			var ul = document.getElementById('li-comment-' + object.data.comment_parent).getElementsByTagName('ul')[0];
			ul.innerHTML = ul.innerHTML + html;
		}
	}	
}



addComment = {
	moveForm : function(commId, parentId, respondId, postId) {
		var t = this, div, comm = t.I(commId), respond = t.I(respondId), cancel = t.I('cancel-comment-reply-link'), parent = t.I('comment_parent'), post = t.I('comment_post_ID');

		if ( ! comm || ! respond || ! cancel || ! parent )
			return;

		t.respondId = respondId;
		postId = postId || false;

		if ( ! t.I('wp-temp-form-div') ) {
			div = document.createElement('div');
			div.id = 'wp-temp-form-div';
			div.style.display = 'none';
			respond.parentNode.insertBefore(div, respond);
		}

		comm.parentNode.insertBefore(respond, comm.nextSibling);
		if ( post && postId )
			post.value = postId;
		parent.value = parentId;
		cancel.style.display = '';

		cancel.onclick = function() {
			var t = addComment, temp = t.I('wp-temp-form-div'), respond = t.I(t.respondId);

			if ( ! temp || ! respond )
				return;

			t.I('comment_parent').value = '0';
			temp.parentNode.insertBefore(respond, temp);
			temp.parentNode.removeChild(temp);
			this.style.display = 'none';
			this.onclick = null;
			return false;
		}

		try { t.I('comment').focus(); }
		catch(e) {}

		return false;
	},

	I : function(e) {
		return document.getElementById(e);
	}
}




