
<?php	
	
	include('../includes/ibt_realtime_utils.php');
	
	session_start();
	
	$appKey = "XRTMLO";
	$authToken = "9a9056df-90c3-49a6-bec2-e528f1f34c66";
	$privateToken = "MnsVGmC65sVx";
	
	if(!isset($_SESSION['oRTCData'])){
		$_SESSION['oRTCData'] = array(
			'ApplicationKey' => $appKey,
			'PrivateKey' => $privateToken,
			'AuthenticationToken' => $authToken
		);
	}
	
	function HttpPost($url, $jsonobj = null, $multipart = false){
		//open connection
		$ch = curl_init();
		
		if(preg_match('/^https:/', $url)){// if ssl?
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		}
		
		$fields = array(
		 'AT' => $_SESSION['oRTCData']['AuthenticationToken'],
		 'AP' => $_SESSION['oRTCData']['ApplicationKey'],
		 'PK' => $_SESSION['oRTCData']['PrivateKey'],
		 'TTL' => 1800,
		 'TP' => count($jsonobj)
		);		
		if($jsonobj){
			foreach($jsonobj as $channel){
				$fields[$channel->name] = ($channel->permission == 'write')? 'w':'r';
			}
		}
		//die(var_dump(CURLOPT_HTTPHEADERS));
		//set the url, number of POST vars, POST data
		curl_setopt($ch, CURLOPT_URL, $url . '/auth/');
		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
		
		/*var_dump($url . '/auth/');
		var_dump(http_build_query($fields));
		die();*/
		
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);		
		
		$result = curl_exec($ch);
		//close connection
		curl_close($ch);		
		return $result;
	}	
	
	
	if(!isset($_SESSION['authentication'])){
		$message = file_get_contents('php://input');
		$channels = json_decode($message);
		
		$balancerUrl = 'http://dev.ortc.balancer.ibt.pt/v1.2/';		
		
		$oRTCUrl = Utils::getOrtcUrl();
		
		$fields = array(
			'AT' => $_SESSION['oRTCData']['AuthenticationToken'],
			'AP' => $_SESSION['oRTCData']['ApplicationKey'],
			'PK' => $_SESSION['oRTCData']['PrivateKey'],
			'TTL' => 1800,
			'TP' => count($channels)
		);
		
		//die($socketIOserver);
		$authentication = Utils::oRTCAuthenticate($oRTCUrl, $fields, $channels);
		
		$appKey = "XRTMLO";
	    $authToken = "9a9056df-90c3-49a6-bec2-e528f1f34c66";
	    $privateToken = "MnsVGmC65sVx";
		$return['applicationKey'] = $appKey;
		$return['authenticationToken'] = $authToken;
		$return['connectionId'] = 'null';
		$return['isAuthenticated'] = 'true';
		
		$_SESSION['authentication'] = $return;
		
		die(json_encode($return));
	} else {
		die(json_encode($_SESSION['authentication']));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	