<?php 

	//DEVELOPMENT
	require_once('../../../../wp-config.php');	
	require_once('../../../../wp-includes/wp-db.php');
	