<script type="text/javascript" src="http://staging.tokbox.com/v0.92/js/TB.min.js"></script>
<?php
	
	error_reporting(0);
	include 'db.php';
	
	$HISTORY_COUNT = 50;
	$MESSAGE_COUNT = 20;
	
	$TABLE = $wpdb->prefix . 'realtime_shoutbox';
	$message = json_decode(file_get_contents('php://input'));
		
	if($message->o == 'GetShoutMessages'){		
		$query = $wpdb->prepare("SELECT TIMESTAMP, shouter AS u, shout AS m FROM (SELECT * FROM $TABLE ORDER BY TIMESTAMP DESC LIMIT 0, 20) sb ORDER BY TIMESTAMP ASC");
		$result = $wpdb->get_results($query);
		echo json_encode($result);
	} else {		
		$shouter = $message->p->u;
		$shout = $message->p->m;
		
		$query  = $wpdb->prepare("insert into $TABLE (shouter, shout) values ('$shouter', '$shout'); ");
				
		$wpdb->query($query);
		$query = $wpdb->prepare("delete from $TABLE where id not in (select * from ((SELECT id FROM $TABLE order by timestamp desc limit 0, $HISTORY_COUNT) as t))");
		if($wpdb->query($query)){
			echo '{"success": "true"}';	
		} else {
			echo '{"success": "false", "query": "' . $query . '"}';
		}				
	} 

	
	
	
	