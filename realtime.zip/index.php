<?php 
/*
Plugin Name: Realtime...
Plugin URI: http://www.ibt.pt
Description: .. real time stuff
Author: ibt
Version: 0.1
*/

require 'includes/ibt_realtime_utils.php';
require 'includes/ibt_realtime_admin.php';
require 'includes/ibt_realtime_post.php';
require 'includes/ibt_realtime_comments.php';
require 'includes/ibt_realtime_videochat.php';


class ibt_realtime{		
	
	function __construct(){
		session_start();	
		include 'xRTML/xrtml.php';
		include 'includes/config.php';	
			
		$this->siteurl = get_option('siteurl');	
		
		$this->admin = new Admin();
		$this->comment = new Comment($this->xrtml);
		$this->post = new Post($this->xrtml);
		if(get_option('realtime_videochat') == '1'){
			$this->videochat = new Videochat($this->xrtml);
		}
		
		// hooks			
		add_action('template_redirect', array($this, 'template_redirect'));
		add_action('wp_footer', array($this, 'wp_footer'));
		//filters		
		add_filter('the_content', array($this, 'the_content'));
	}
	
	function activate_plugin(){
		global $wpdb;
		//this only works the first time, sets the plugin options to default in the database
		add_option('realtime_appkey', '');
		add_option('realtime_authtoken', '');
		add_option('realtime_privatetoken', '');
		add_option('realtime_serverurl','http://developers.realtime.livehtml.net/');
		add_option('realtime_updateposts', '0'); //disables the Blog Posts live injection
		add_option('realtime_postcontainer', ''); //will set the blog's parent element where the posts will be injected
		add_option('realtime_updatecomments', '0'); //disables the Comments live injection
		add_option('realtime_updatelatestposts', '0'); //disables the Latest Posts live injection		
		add_option('realtime_updatelatestposts_container', ''); //will set the latest posts parent element where the posts will be injected
		add_option('realtime_updatelatestposts_index', ''); //will set the latest posts parent element where the posts will be injected
		add_option('realtime_shoutbox', '0'); //disables the Latest Posts live injection		
		add_option('realtime_shoutbox_container', ''); //will set the latest posts parent element where the posts will be injected
		add_option('realtime_shoutbox_index', ''); //will set the latest posts parent element where the posts will be injected
		add_option('realtime_videochat', '0'); //will set the latest posts parent element where the posts will be injected
		add_option('realtime_videochat_apikey', ''); //will set the latest posts parent element where the posts will be injected
		add_option('realtime_videochat_sessionid', ''); //will set the latest posts parent element where the posts will be injected
		add_option('realtime_videochat_token', ''); //will set the latest posts parent element where the posts will be injected
						
		$table_name = $wpdb->prefix . 'realtime_shoutbox';
		$sql = "CREATE TABLE IF NOT EXISTS " . $table_name . " (
		  id bigint(11) NOT NULL AUTO_INCREMENT,
		  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		  shouter varchar(128) NOT NULL,
		  shout tinytext NOT NULL,
		  UNIQUE KEY id (id)
		);";
		
		//die($sql);
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
	
	//this runs on every page, it just loads the scripts necessary for realtime
	function template_redirect(){
		wp_enqueue_script('base', plugins_url('/js/base.js', __FILE__), null, null, false);
		wp_enqueue_script('plugin', plugins_url('/js/plugin.js', __FILE__),  array('jquery'), null, false);		
		//wp_enqueue_script('xRTML', plugins_url('/js/xrtml_unobfuscated.js', __FILE__), null, null, false);
		wp_enqueue_script('tokbox', 'http://staging.tokbox.com/v0.92/js/TB.min.js', null, null, false);					
		//stylesheet for our plugin stuff
		wp_enqueue_style('realtime', plugins_url('/css/realtime.css', __FILE__));
	}
	
	//just to get the post ID if we're in a single post page
	function the_content($content){
		global $post;		
		$this->post_id = $post->ID;
		return $content;
	}

	//include the necessary xRTML tags
	function wp_footer(){
		echo '<script type="text/javascript" src="' . $this->xrtml->jsPath . '"></script>';
		echo $this->xrtml->config->toXRTML();
						
		if(!is_admin()){
			if(is_single()){
				$this->executeCallback = 'createComment';
				$this->trigger = md5('RTML_wordpress-comments-' . $this->post_id);
			} else{				
				$this->trigger = md5('RTML_wordpress-posts-' . $this->siteurl);
				$this->executeCallback = 'createAlert';
				 
				if(get_option('realtime_updateposts') == '1'){ 
					$this->repeater_post = Utils::fileToString(plugins_url('/realtime/templates/post_repeater.html'));
					include 'includes/post_repeater.php';
				}			
				if(get_option('realtime_updatelatestposts') == '1'){
					$this->repeater_latest_posts = Utils::fileToString(plugins_url('/realtime/templates/latest_posts_repeater.html'));
					include 'includes/latestposts_repeater.php';
				}				
			}
			if(get_option('realtime_videochat') == '1'){					
				include 'includes/videochat.php';
			}
			if(get_option('realtime_shoutbox') == '1'){					
				include 'includes/shoutbox.php';
			}			
			if(get_option('realtime_updatelatestposts') == '1'){	
				include 'includes/latestPosts.php';
			}			
			include 'includes/execute.php';						
		}		
	}
}

/* Initialise ourselves */
add_action( 'plugins_loaded', create_function( '', 'global $ibt_realtime; $ibt_realtime = new ibt_realtime;' ));
register_activation_hook( __FILE__, array('ibt_realtime', 'activate_plugin') );
?>