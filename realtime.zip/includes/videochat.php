
<?php
	
	$videochat = $this->xrtml->addTag('videochat');
	$videochat->id = 'videochat';
	$videochat->channelid = $this->xrtml->config->connections->array[0]->channels->array[0]->name;
	$videochat->apikey = get_option('realtime_videochat_apikey');			
	$videochat->sessionid = get_option('realtime_videochat_sessionid');			
	$videochat->token = get_option('realtime_videochat_token');
	$videochat->generatehtml = true;
	$videochat->role = is_admin()? 'moderator': 'publisher';
	$videochat->persist = true;
	$videochatTrigger = $videochat->triggers->add('global_videoChat');
	
	echo $videochat->toXRTML();
	
?>


