<div id="latestPosts" realtime_index="<?php echo get_option('realtime_updatelatestposts_index'); ?>">
   <h3>Latest Posts dsfsdfdsfds</h3>
   <?php $latestposts = get_posts(array('numberposts' => 5, 'orderby' => 'post_date', 'order' => 'desc')); ?>
   <ul class="realtimeLatestPosts" id="realtimeLatestPosts">
      <?php foreach($latestposts as $post){ ?>
         <li>
            <a href="<?php echo $post->guid; ?>"><?php echo $post->post_title; ?></a>
         <div><?php echo $post->post_date; ?></div>
      </li>
      <? } ?>
   </ul>
</div>

<script type="text/javascript">	
	(function(){
		var selector = "<?php echo get_option('realtime_updatelatestposts_container'); ?>";
		jQuery(selector).html(jQuery('#latestPosts'));
	})();
</script>
