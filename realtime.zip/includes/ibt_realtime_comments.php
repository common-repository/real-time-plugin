<?php 
	
	class Comment{	
		function __construct($xrtml){
			//hooks and filters
			if(get_option('realtime_updatecomments') == '1'){
				add_action('wp_insert_comment', array($this, 'wp_insert_comment'), 10, 2);
				add_filter('comments_template', array($this,'comments_template'), 1, 1);
			}
			//die('here');			
			update_option('comment_moderation', '0');
			$this->xrtml = $xrtml;
			$this->channel = $xrtml->config->connections->array[0]->channels->array[0]->name;
			$this->pagecomments = array();		
		}
		
		function wp_insert_comment($commentID, $comment){
			$comment->htmlblock = Comment::getCommentHtmlBlock($comment);
			$rtml['t'] = md5('RTML_wordpress-comments-' . $comment->comment_post_ID);
			$rtml['d'] = $comment;
			$broadcast['xrtml'] = $rtml;	
			
			$message = json_encode($broadcast);
			$this->xrtml->sendMessage($this->channel , $message);
		}
		
		function comments_template($template){
			return dirname(__FILE__) . "\my_comments_template.php";
		}

		//substitute with a database solution
		static function getCommentHtmlBlock($comment){
			global $wpdb;
			
			$gravatarsize = $comment->comment_parent == 0? '68' : '39';
			
			$comment->gravatar = 'http://www.gravatar.com/avatar/' . md5(strtolower(trim($comment->comment_author_email))) . '?d=mm&s=' . $gravatarsize;
			$bypostauthor = $comment->user_id != '0' ? 'bypostauthor' : '';
			$siteurl = get_option('siteurl');
		
			$comment->html = '';
			$comment->html .='<li id="li-comment-' . $comment->comment_ID . '" class="comment byuser ' . $bypostauthor . '">';
			$comment->html .='	<div id="comment-' . $comment->comment_ID . '" class="comment">';
			$comment->html .='		<div class="comment-meta">';
			$comment->html .='			<div class="comment-author vcard">';
			$comment->html .='				<img alt="" src="' . $comment->gravatar . '" class="avatar avatar-'. $gravatarsize . ' photo" height="'. $gravatarsize . '" width="'. $gravatarsize . '" />';
			$comment->html .='				<span class="fn">';
			$comment->html .='					' . $comment->comment_author . '';
			$comment->html .='				</span> on';
			$comment->html .='				<a href="' . $siteurl . '?p=' . $comment->comment_post_ID . '#comment-' . $comment->comment_ID . '">';
			$comment->html .='					<span class="time">' . $comment->comment_date . '</span>';
			$comment->html .='				</a>';
			$comment->html .='				<span class="says">said:</span>';			
			$comment->html .='			</div>';
			$comment->html .='		</div>';
			$comment->html .='		<div class="comment-content">';
			$comment->html .='			' . str_replace('\"', '"', Utils::getHtml($comment->comment_content) . '');
			$comment->html .='		</div>';
			$comment->html .='		<div class="reply">';
			$comment->html .='			<a class="comment-reply-link"';
			$comment->html .='				href="/wordpress/?p=' . $comment->comment_post_ID . '&amp;replytocom=' . $comment->comment_ID . '#respond"';
			$comment->html .='				onclick="return addComment.moveForm(\'comment-' . $comment->comment_ID . '\', \'' . $comment->comment_ID . '\', \'respond\', \'' . $comment->comment_post_ID . '\')">';
			$comment->html .='					Reply <span>&darr;</span>';
			$comment->html .='			</a>';
			$comment->html .='		</div>';
			$comment->html .='	</div>';
			$comment->html .='</li>';
			
			$args['post_id'] = $comment->comment_post_ID;
			$result = get_comments( $args );			
			$comment->postHasComments = sizeof($result) > 1;
			if(!$comment->postHasComments){
				return '<h2 id="comments-title"><span id="nposts">One</span> thoughts on "<span>teste</span>"</h2><ol class="commentlist" id="commentslist">' . $comment->html . '</ol>';
			}			
			
			$args['parent'] = $comment->comment_post_ID;
			$result = get_comments( $args );	
			$comment->commentHasSiblings = sizeof($result) > 1;
			if(!$comment->commentHasSiblings){
				return '<ul class="children">' . $comment->html . '</ul>';
			}
			
			return $comment->html;
		}
		
		function realtimeComment( $comment, $args, $depth ) {
			$GLOBALS['comment'] = $comment;			
			?>
			<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
				<div id="comment-<?php comment_ID(); ?>" class="comment">
					<div class="comment-meta">
						<div class="comment-author vcard">
							<?php
								$avatar_size = 68;
								if ( '0' != $comment->comment_parent )
									$avatar_size = 39;

								echo get_avatar( $comment, $avatar_size );

								/* translators: 1: comment author, 2: date and time */
								printf( __( '%1$s on %2$s <span class="says">said:</span>', '' ),
									sprintf( '<span class="fn">%s</span>', get_comment_author_link() ),
									sprintf( '<a href="%1$s"><time pubdate datetime="%2$s">%3$s</time></a>',
										esc_url( get_comment_link( $comment->comment_ID ) ),
										get_comment_time( 'c' ),
										/* translators: 1: date, 2: time */
										sprintf( __( '%1$s at %2$s', '' ), get_comment_date(), get_comment_time() )
									)
								);
							?>

							<?php edit_comment_link( __( 'Edit', '' ), '<span class="edit-link">', '</span>' ); ?>
						</div><!-- .comment-author .vcard -->
					</div>

					<div class="comment-content"><?php comment_text(); ?></div>

					<div class="reply">
						<?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( 'Reply <span>&darr;</span>', '' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
					</div><!-- .reply -->
				</div><!-- #comment-## -->
			<?php					
		}		
	}