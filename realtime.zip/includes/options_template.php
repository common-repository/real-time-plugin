<?php
	if(isset($_POST['submit']) && wp_verify_nonce($_POST['_wpnonce'],'save_realtime_options')){
		update_option('realtime_appkey', mysql_real_escape_string($_POST['appkey']));
		update_option('realtime_authtoken', mysql_real_escape_string($_POST['authtoken']));
		update_option('realtime_privatetoken', mysql_real_escape_string($_POST['privatetoken']));
		update_option('realtime_serverurl', mysql_real_escape_string($_POST['serverurl']));
		update_option('realtime_updateposts', mysql_real_escape_string($_POST['updateposts']));		
		update_option('realtime_postcontainer', mysql_real_escape_string($_POST['postcontainer']));		
		update_option('realtime_updatecomments', mysql_real_escape_string($_POST['updatecomments']));	
		update_option('realtime_updatelatestposts', mysql_real_escape_string($_POST['updatelatestposts']));
		update_option('realtime_updatelatestposts_container', mysql_real_escape_string($_POST['updatelatestposts_container']));
		update_option('realtime_updatelatestposts_index', mysql_real_escape_string($_POST['updatelatestposts_index']));
		update_option('realtime_shoutbox', mysql_real_escape_string($_POST['shoutbox']));
		update_option('realtime_shoutbox_container', mysql_real_escape_string($_POST['shoutbox_container']));
		update_option('realtime_shoutbox_index', mysql_real_escape_string($_POST['shoutbox_index']));
		update_option('realtime_videochat', mysql_real_escape_string($_POST['videochat']));				
		update_option('realtime_videochat_apikey', mysql_real_escape_string($_POST['videochat_apikey']));			
		update_option('realtime_videochat_sessionid', mysql_real_escape_string($_POST['videochat_sessionid']));			
		update_option('realtime_videochat_token', mysql_real_escape_string($_POST['videochat_token']));					
	} 
?>

<style type="text/css">	
	div.left{float:left;}
	#divform{width:650px;}
	
	#options_form{padding:20px 5px;}
	#options_form label{display:inline-block;width:150px;}
	#options_form input.text{width:300px;}
	#serverurl{width:400px;}
	
	#lisubmit{width:542px;text-align:right;}
	#lisubmit input{padding:3px 4px;}
	
	#divinstructions ul{padding:0;margin:0;min-width:300px;}
	#latestInstructions div {padding:5px 10px;background:#cdcdcd;}
</style>


<div class="wrap">	
	<div id="divform" class="left">
		<h3>RealTime Options</h3>
		<form id="options_form" method="post">
			<?php wp_nonce_field('save_realtime_options'); ?>
			<fieldset>				
				<input type="hidden" name="blogid" id="blogid" value="<?php echo md5('wordpress'. get_option('siteurl')); ?>" />
				
				<h3>Realtime Authentication Data</h3>
				<ul>
					<li>
						<div>
							<label for="appkey">Application Key</label>
							<input type="text" class="text" name="appkey" id="appkey" value="<?php echo get_option('realtime_appkey'); ?>" />
						</div>
						<div>
							<label for="authtoken">Authentication Token</label>
							<input type="text" class="text" name="authtoken" id="authtoken" value="<?php echo get_option('realtime_authtoken'); ?>" />
						</div>
						<div>
							<label for="privatetoken">Private Token</label>
							<input type="text" class="text" name="privatetoken" id="privatetoken" value="<?php echo get_option('realtime_privatetoken'); ?>" />
						</div>
						<div>
							<label for="serverurl">Server URL</label>
							<input type="text" class="text" name="serverurl" id="serverurl" value="<?php echo get_option('realtime_serverurl'); ?>" />
						</div>
					</li>					
				</ul>
				
				<h3>Realtime Blog Posts</h3>
				<ul>
					<li>
						<div>
							<label for="updateposts">Update Posts?</label>
							<span>Yes</span><input <?php if(get_option('realtime_updateposts')== '1') echo 'checked'; ?> type="radio" name="updateposts" value="1">
							<span>No</span><input <?php if(get_option('realtime_updateposts')== '0') echo 'checked'; ?> type="radio" name="updateposts" value="0">
						</div>
						<div>
							<label for"postcontainer">Container ID</label>
							<input type="text" class="text" name="postcontainer" id="postcontainer" value="<?php echo get_option('realtime_postcontainer'); ?>" />
							<div>Please edit the html structure at "&lt;wordpressdir&gt;/wp-content/plugins/realtime/templates/post_repeater.php"</div>
						</div>
					</li>					
				</ul>
				<h3>Realtime Comments</h3>
				<ul>
					<li>						
						<label for="updateposts">Update Comments?</label>
						<span>Yes</span><input <?php if(get_option('realtime_updatecomments')== '1') echo 'checked'; ?> type="radio" name="updatecomments" value="1">
						<span>No</span><input <?php if(get_option('realtime_updatecomments')== '0') echo 'checked'; ?> type="radio" name="updatecomments" value="0">
						<div>Please apply the necessary css styles at "&lt;wordpressdir&gt;/wp-content/plugins/realtime/css/realtime.css"</div>
					</li>
				</ul>
				<h3>Realtime ShoutBox</h3>
				<ul>
					<li>
						<div>
							<label for="shoutbox">ShoutBox?</label>
							<span>Yes</span><input <?php if(get_option('realtime_shoutbox')== '1') echo 'checked'; ?> type="radio" name="shoutbox" value="1">
							<span>No</span><input <?php if(get_option('realtime_shoutbox')== '0') echo 'checked'; ?> type="radio" name="shoutbox" value="0">
						</div>
						<div>
							<label for"shoutbox_container">Container (selector)</label>
							<input type="text" class="text" name="shoutbox_container" id="shoutbox_container" value="<?php echo get_option('realtime_shoutbox_container'); ?>" />							
						</div>
						<div>
							<label for"shoutbox_index">Index</label>
							<input type="text" class="text" name="shoutbox_index" id="shoutbox_index" value="<?php echo get_option('realtime_shoutbox_index'); ?>" />							
						</div>					
					</li>
					
				</ul>			
				<h3>Realtime Latest Posts</h3>
				<ul>
					<li>
						<div>
							<label for="updatelatestposts">Update Latest Posts List?</label>
							<span>Yes</span><input <?php if(get_option('realtime_updatelatestposts')== '1') echo 'checked'; ?> type="radio" name="updatelatestposts" value="1">
							<span>No</span><input <?php if(get_option('realtime_updatelatestposts')== '0') echo 'checked'; ?> type="radio" name="updatelatestposts" value="0">
						</div>
						<div>
							<label for"updatelatestposts_container">Container (selector)</label>
							<input type="text" class="text" name="updatelatestposts_container" id="updatelatestposts_container" value="<?php echo get_option('realtime_updatelatestposts_container'); ?>" />							
						</div>
						<div>
							<label for"updatelatestposts_index">Index</label>
							<input type="text" class="text" name="updatelatestposts_index" id="updatelatestposts_index" value="<?php echo get_option('realtime_updatelatestposts_index'); ?>" />							
						</div>
						<!--
						<div id="latestInstructions">
							you should copy and paste this code into anywhere in your template, and style it in "realtime.css"
							<div>
								&lt;div&gt;<br />
								&nbsp;&nbsp;&nbsp;&lt;h3&gt;Latest Posts&lt;/h3&gt;<br />
								&nbsp;&nbsp;&nbsp;&lt;?php $latestposts = get_posts(array('numberposts' =&gt; 5, 'orderby' =&gt; 'post_date', 'order' =&gt; 'desc')); ?&gt;<br />
								&nbsp;&nbsp;&nbsp;&lt;ul class="realtimeLatestPosts" id="realtimeLatestPosts"&gt;<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;?php foreach($latestposts as $post){ ?&gt;<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;li&gt;<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;a href="&lt;?php echo $post->guid; ?&gt;">&lt;?php echo $post->post_title; ?&gt;&lt;/a&gt;<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;div&gt;&lt;?php echo $post-&gt;post_date; ?&gt;&lt;/div&gt;<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/li&gt;<br />
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;? } ?&gt;<br />
								&nbsp;&nbsp;&nbsp;&lt;/ul&gt;<br />
								&lt;/div&gt;
							</div>
						</div>
						-->
					<li>
				</ul>
				
				<h3>Realtime Video Chat</h3>
				<ul>
					<li>
						<div>
							<label for="videochat">Video Chat?</label>
							<span>Yes</span><input <?php if(get_option('realtime_videochat')== '1') echo 'checked'; ?> type="radio" name="videochat" value="1">
							<span>No</span><input <?php if(get_option('realtime_videochat')== '0') echo 'checked'; ?> type="radio" name="videochat" value="0">
						</div>
						<div>
							<label for"videochat_apikey">API Key</label>
							<input type="text" class="text" name="videochat_apikey" id="videochat_apikey" value="<?php echo get_option('realtime_videochat_apikey'); ?>" />							
						</div>
						<div>
							<label for"videochat_sessionid">Session ID</label>
							<input type="text" class="text" name="videochat_sessionid" id="videochat_sessionid" value="<?php echo get_option('realtime_videochat_sessionid'); ?>" />							
						</div>
						<div>
							<label for"videochat_token">Token</label>
							<input type="text" class="text" name="videochat_token" id="videochat_token" value="<?php echo get_option('realtime_videochat_token'); ?>" />							
						</div>
					</li>
					
				</ul>				
				<ul>
					<li id="lisubmit">
						<input type="submit" name="submit" id="submit" value="Save" />
					</li>
				</ul>
			</fieldset>	
		</form>
	</div>
	<div id="divinstructions" class="left">
		<h3></h3>
		<ul>
			<li>
				
			</li>
		</ul>
	</div>
	<div style="clear:both"></div>
</div>

<script type="text/javascript">
	jQuery(function(){
		if(jQuery('input[name=updatelatestposts]:checked').val() == '0'){
			jQuery('#latestInstructions').hide();
		}
		jQuery('input[name=updatelatestposts]').click(function(){//alert('here');
			if(jQuery(this).val() == '1'){
				jQuery('#latestInstructions').show();
			} else{
				jQuery('#latestInstructions').hide();
			}
		});
	})
</script>















