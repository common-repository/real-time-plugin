<?php
 	
 	$repeater_posts = $this->xrtml->addTag('repeater');
	$repeater_posts->receiveownmessages = true;
	$repeater_posts->channelid = $this->xrtml->config->connections->array[0]->channels->array[0]->name;
	$repeater_posts->target = get_option('realtime_postcontainer');
	$repeater_posts->index = 'begin';		
	$template1 = $repeater_posts->template->content = $this->repeater_post;
	//die(var_dump($repeater_posts));
	$trigger_repeater_posts = $repeater_posts->triggers->add($this->trigger);
	
	echo $repeater_posts->toXRTML();
 	
?> 
 
