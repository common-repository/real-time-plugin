<?php

	class Utils {
	
		//public static $curlurl = 'http://lib.rtml.co/blogger/';
		public static $curlurl = 'http://localhost:53916/xrtml/';
		//public static $curlurl = 'http://localhost/xrtml/';
		//public static $curlurl = 'http://apadez-ibt/xrtml/';
				
		static function getOrtcUrl(){
			//return 'http://192.168.1.119:8080/';
			//return 'http://192.168.1.107:8080/';
			//return 'http://107.20.235.150/';
		
			$ortcLoadBalancer = 'http://dev.ortc.balancer.ibt.pt/v1.2/';
			$url = $ortcLoadBalancer . '?t=' . time();
			$result = Utils::HttpPost($url , '');
			$startindex = strpos($result, '"') + 1;
			$result = substr($result, $startindex);
			$endindex = strpos($result, '"');
			$ortcUrl = substr($result, 0, $endindex);
			return $ortcUrl;
		}
		
		//to be deprecated, when we have a PHP API for oRTC
		static function HttpPost($url, $jsonobj, $multipart = false){		
			//open connection
			$ch = curl_init();
			//die(var_dump(CURLOPT_HTTPHEADERS));
			//set the url, number of POST vars, POST data
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
			curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonobj);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			//execute post
			$result = curl_exec($ch);		
			//close connection
			curl_close($ch);		
			return $result;
		}
		
		static function oRTCAuthenticate($url, $fields, $channels){
			//open connection
			$ch = curl_init();
			
			if(preg_match('/^https:/', $url)){// if ssl?
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			}			
					
			if($channels){
				foreach($channels as $channel){
					$fields[$channel->name] = ($channel->permission == 'write')? 'w':'r';
				}
			}
			//die(var_dump(CURLOPT_HTTPHEADERS));
			//set the url, number of POST vars, POST data
			curl_setopt($ch, CURLOPT_URL, $url . '/auth/');
			//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
			
			/*var_dump($url . '/auth/');
			var_dump(http_build_query($fields));
			die();*/
			
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);		
			
			$result = curl_exec($ch);
			//close connection
			curl_close($ch);		
			return $result;
		}
		
		//resolves the problem of html encoding of the WYSIWYG
		static function getHtml($html){
			$content = explode(PHP_EOL . PHP_EOL, $html);
			$htmlcontent = '';
			foreach($content as $line){
				$htmlcontent .= '<p>' . str_replace(PHP_EOL, '<br />' , $line) . '</p>';
			}
			return $htmlcontent;
		}
		
		static function fileToString($path){
			$file = fopen($path, 'r');
			$string = '';
			while (($buffer = fgets($file, 4096)) !== false) {
				$string .= $buffer;
			}
			fclose($file);
			return $string;
		}
		
		static function getCurlUrl(){
			return self::$curlurl;
		}
	}