 <?php
 
 	$repeater_latestposts = $this->xrtml->addTag('repeater');
	$repeater_latestposts->id = 'repeater_latestposts';
	$repeater_latestposts->channelid = $this->xrtml->config->connections->array[0]->channels->array[0]->name;
	$repeater_latestposts->target = '#latestPosts ul';
	$repeater_latestposts->index = 'begin';
	$template1 = $repeater_latestposts->template->content = $this->repeater_latest_posts;
	$trigger_repeater_posts = $repeater_latestposts->triggers->add($this->trigger);
	
	echo $repeater_latestposts->toXRTML();
 ?>
 
 