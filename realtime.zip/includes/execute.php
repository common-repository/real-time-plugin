
<?php
	$execute_comments = $this->xrtml->addTag('execute');
	$execute_comments->id = 'execute_comments';
	$execute_comments->callback = $this->executeCallback;
	$trigger_execute_comments = $execute_comments->triggers->add($this->trigger);
	
	echo $execute_comments->toXRTML();
?>

