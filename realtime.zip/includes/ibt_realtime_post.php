<?php 
	
	class Post{	
		function __construct($xrtml){
			$this->xrtml = $xrtml;
			$this->channel = $xrtml->config->connections->array[0]->channels->array[0]->name;
			$this->siteurl = get_option('siteurl');			
			//hooks
			add_action( 'publish_post', array($this, 'publish_post'));			
		}
		
		//this runs whenever a post is published (new or edited)
		function publish_post(){			
			//this returns if it is not a new post
			if(!strpos($_POST['_wp_http_referer'], 'post-new.php')){
				return;
			}
			
			$this->trigger = md5('RTML_wordpress-posts-' . $this->siteurl);
			
			//Generates the post content to be sent as a JSON message
			$broadcast = array();		
			$rtml['t'] = $this->trigger;
			$rtml['a'] = 'insert';
			$rtml['d'] = $this->getPost();
			$broadcast['xrtml'] = $rtml;
			$message = json_encode($broadcast);
			//sends the message
			$this->xrtml->sendMessage($this->channel , $message);							
		}
		
		function getPost(){			
			$post = array();
			$post['siteurl'] = $this->siteurl;
			$user = get_userdata($_POST['post_author']);
			$post['authorname'] = $user->display_name;
			$post['authorid'] = $_POST['post_author'];
			$post['title'] = str_replace('\"', '"', $_POST['post_title']);
			$post['content'] = str_replace('\"', '"', Utils::getHtml($_POST['content']));
			$post['postid'] = $_POST['post_ID'];
			$post['posturl'] = $this->siteurl . '?p=' . $_POST['post_ID'];
			$post['postdate'] = date("F j, Y");
			$post['categories'] = '';
			$categories = get_categories();
			
			foreach($categories as $category){
				if(array_search($category->term_id, $_POST['post_category'])){
					$post['categories'] .= '<a href="' . get_option('siteurl') . '/category/' . $category->slug . '/" ';
					$post['categories'] .= 'title="View All posts in ' . $category->name . '" rel="category tag">';
					$post['categories'] .=  $category->name . '</a>, ';
				}
			}			
			return $post;
		}
	}	
		
	