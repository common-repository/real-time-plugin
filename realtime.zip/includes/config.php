<?php
	$this->xrtml = new xRTML();
	
	$this->xrtml->jsPath = plugins_url('realtime/js/xrtml_unobfuscated.js');
	$this->xrtml->config->debug = false;
	$xrtmlconnection = $this->xrtml->config->connections->add('wordpressConnection');
	$xrtmlconnection->url = get_option('realtime_serverurl');
	$xrtmlconnection->appkey = get_option('realtime_appkey');
	$xrtmlconnection->authtoken = get_option('realtime_authtoken');
	$xrtmlconnection->privatekey = get_option('realtime_privateToken');
	$xrtmlchannel = $xrtmlconnection->channels->add(md5('wordpress' . get_option('siteurl')));
	$xrtmlchannel->permission = 'write';
	
	$this->xrtml->authenticate();
	
	