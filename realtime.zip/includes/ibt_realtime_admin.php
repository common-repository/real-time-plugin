<?php 
	class Admin{
		function __construct(){
			//hooks
			add_action('admin_menu', array($this, 'generate_admin_menu'));			
		}
		
		//generates the realtime settings page, 
		function generate_admin_menu() {
			add_options_page('Real Time Options', 'Realtime Plugin', 'manage_options', '', array($this, 'my_plugin_options'));
		}
		function my_plugin_options() {
			if (!current_user_can('manage_options'))  {
				wp_die( __('You do not have sufficient permissions to access this page.') );
			}
			include('options_template.php');		
		}
	}