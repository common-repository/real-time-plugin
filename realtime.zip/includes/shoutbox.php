<div id="shoutBox" realtime_index="<?php echo get_option('realtime_shoutbox_index'); ?>">
	<h2>Realtime ShoutBox</h2>
	
	<div id="outershouts">
    	<div id="shouts"></div>
    </div>
    
    <div id="loginArea" style="display:block;">
    	<label>Username:</label>
        <input type="text" id="iUsername" maxlength="15" />
        <input type="button" id="bEnterChat" value="start" />
    </div>
    <div id="userArea" style="display:none;">
        <label id="lbUsername"></label>
        <textarea id="taUserInput" rows="2" cols="20"></textarea>
    </div>
</div>

<?php
	
	$shoutbox = $this->xrtml->addTag('shoutbox');
	$shoutbox->id = 'myShoutBox';
	$shoutbox->historyrepository = plugins_url('/realtime/handlers/shoutbox.php');
	$shoutbox->receiveownmessages = false;
	$shoutbox->channelid = $this->xrtml->config->connections->array[0]->channels->array[0]->name;
	$triggerShoutbox = $shoutbox->triggers->add('xrtml_shoutbox');
	$shoutboxElement1 = $shoutbox->elements->add('shoutbox');
	$shoutboxElement1->value = 'outershots';
	$shoutboxElement2 = $shoutbox->elements->add('shouts');
	$shoutboxElement2->value = 'shouts';
	$shoutboxElement3 = $shoutbox->elements->add('loginArea');
	$shoutboxElement3->value = 'loginArea';
	$shoutboxElement4 = $shoutbox->elements->add('userArea');
	$shoutboxElement4->value = 'userArea';
	$shoutboxElement5 = $shoutbox->elements->add('iUsername');
	$shoutboxElement5->value = 'iUsername';
	$shoutboxElement6 = $shoutbox->elements->add('bEnterChat');
	$shoutboxElement6->value = 'bEnterChat';
	$shoutboxElement7 = $shoutbox->elements->add('lbUsername');
	$shoutboxElement7->value = 'lbUsername';
	$shoutboxElement8 = $shoutbox->elements->add('taUserInput');
	$shoutboxElement8->value = 'taUserInput';
	
	echo $shoutbox->toXRTML();

?>


<script type="text/javascript">

	(function(){
		var selector = "<?php echo get_option('realtime_shoutbox_container'); ?>";
		jQuery(selector).append(jQuery('#shoutBox'));
				
		setInterval(function(){
				shoutsHeight = jQuery('#shoutBox #shouts').outerHeight();
				jQuery('#shoutBox #shouts').scrollTop(jQuery('#shoutBox #shouts').outerHeight() * 5);
		}, 100);		
	})();	
	
	jQuery(function(){
		jQuery('#iUsername').keypress(function (e) {
	        if (e.charCode == 13) {
	            jQuery('#bEnterChat').trigger('click');
	        }
	    });
	});
    
</script>