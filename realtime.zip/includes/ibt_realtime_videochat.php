<?php 
	
	class Videochat{	
		function __construct($xrtml){	
			$this->channel = $xrtml->config->connections->array[0]->channels->array[0]->name;
			$this->apikey = get_option('realtime_videochat_apikey');			
			$this->sessionid = get_option('realtime_videochat_sessionid');			
			$this->token = get_option('realtime_videochat_token');			
			//hooks
			add_action( 'publish_post', array($this, 'publish_post'));
		}
		
	}
	
	