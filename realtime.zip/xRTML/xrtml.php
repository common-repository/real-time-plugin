<?php
	
	class xRTML {
		public $config;
		public $jsPath;
		public $authenticated;
		public $tags;
		
		public function __construct(){
			$this->authenticated = false;
			$this->tags = new xRTMLArray('tag');
			xRTMLTagFactory::createTagsArray();
			$this->config = xRTMLTagFactory::createTag('config');
		}
		
		public function addTag($tagName){
			if(!array_key_exists(strtolower($tagName), xRTMLTagFactory::$tagsArray) || xRTMLTagFactory::$tagsArray[$tagName]->extends != 'Tag'){
				throw new Exception("There is no tag named " . $tagName);
			}
			$newTag = xRTMLTagFactory::createTag($tagName);
			array_push($this->tags->array, $newTag);
			return $newTag;
		}
		
		public function toXRTML(){			
			if(!isset($this->jsPath)){
				throw new Exception('$xrtml->jsPath (the path to the xRTML javascript file) must be set.');
			}
			$html = "<!-- ******************************* xRTML ******************************* -->\r\n";
			$html .= '<script type="text/javascript" src="' . $this->jsPath . '"></script>' . "\r\n";
			$html .= $this->config->toXRTML();
			if(isset($this->tags) && sizeof($this->tags) > 0){
				foreach($this->tags as $tag){
					$html .= $tag->toXRTML();					
				}
			}
			$html .= "<!-- **************************** end xRTML ****************************** -->\r\n\r\n";
			return $html;
		}
		
		public function authenticate(){
			foreach($this->config->connections as $connection){
				$fields = array(
					'AT' => $connection->authtoken,
					'AP' => $connection->appkey,
					'PK' => $connection->privatekey,
					'TTL' => 1800
				);
				$fields['TP'] = sizeof($connection->channels);
				foreach($connection->channels as $channel){
					$fields[$channel->name] = ($channel->permission == 'write')? 'w':'r';
				}
				$ch = curl_init();
				if(preg_match('/^https:/', $connection->url)){// if ssl?
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
				}				
				curl_setopt($ch, CURLOPT_URL, $connection->url . '/auth');
				curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				
				$result = curl_exec($ch);
				if(@curl_getinfo($ch, CURLINFO_HTTP_CODE) != 201 && @curl_getinfo($ch, CURLINFO_HTTP_CODE) != 200 ){
					error_log("There was an error trying to establish the Connection " . $connection->id, 0);
				}
				curl_close($ch);
			}
			$this->authenticated = true;
			return true;
		}

		public function sendMessage($channel, $message){
			foreach($this->config->connections as $connection){
				$fields = array(
					'AuthenticationToken' => $connection->authtoken,
					'ApplicationKey' => $connection->appkey,
					'PrivateKey' => $connection->privatekey,
					'Channel' => $channel,
					'Content' => $message
				);
				$ch = curl_init();
				if(preg_match('/^https:/', $connection->url)){// if ssl?
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
				}
				curl_setopt($ch, CURLOPT_URL, $connection->url . '/sendMessage');
				curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$result = curl_exec($ch);
				if(@curl_getinfo($ch, CURLINFO_HTTP_CODE) != 201 && @curl_getinfo($ch, CURLINFO_HTTP_CODE) != 200 ){
					error_log("There was an error trying to send the message " . $message, 0);
				}
				curl_close($ch);
			}
			return true;
		}
		
		public function createMessage($trigger, $action, $data){
			$message['xrtml'] = array();
			$message['xrtml']['t'] = $trigger;
			$message['xrtml']['a'] = $action;
			$message['xrtml']['d'] = $data;
			return json_encode($message);			
		}
	}		
	
	class xRTMLBaseTag{
		public function __construct($tagSettings){
			if(isset($tagSettings->collections)){
				foreach($tagSettings->collections as $collectionName => $collectionValue){
					$collection = strtolower($collectionName);									
					$collectionClass = substr($collection, 0, strlen($collection) - 1);
					$this->$collection = new xRTMLArray($collectionClass);
				}
			}
			if(array_key_exists('children', $tagSettings)){
				foreach($tagSettings->children as $childName => $childValue ){
					$childSettings = xRTMLTagFactory::getTagSettings($childName);
					$childName = strtolower($childName);
					$this->$childName = xRTMLTagFactory::createTag($childName);
					if(isset($childSettings->content)){
						$this->$childName->content = '';
					}
				}
			}
		}
		
		public function toXRTML($deep = 0){			
			$html = '';
			$tabs = '';
			$className = get_class($this);
			$tagName = str_replace('xRTML', '', $className);
			$tagSettings = xRTMLTagFactory::getTagSettings($tagName);
			$this->validateTag();
			if($deep == 0){
				$html .= "\r\n";
			}
			for($cont = 0; $cont < $deep; $cont++){
				$tabs .= "\t";
			}
			$html .= $tabs . "<xrtml:$tagName";
			if($tagName == 'connection'){
				$html .= ' authenticate="false"';
			}
			if(isset($tagSettings->attributes) && sizeof($tagSettings->attributes) > 0){
				foreach($tagSettings->attributes as $attrName => $attrVal){
					if(isset($this->$attrName)){
						if(is_bool($this->$attrName)){
							$attrVal = $this->$attrName? "true" : "false";
						} else {
							$attrVal = $this->$attrName;
						}
						$html .= " $attrName=\"" . $attrVal . "\"";
					}
				}
			}
			if(isset($tagSettings->events) && sizeof($tagSettings->events) > 0){
				foreach($tagSettings->events as $eventName => $eventValue){
					if(isset($this->$eventName)){
						$html .= " $eventName=\"" . $this->$eventName . "\"";
					}
				}
			}
			if(isset($tagSettings->collections) || isset($tagSettings->children) || isset($tagSettings->content)){
				$html .= ">\r\n";
				if(isset($tagSettings->collections)){
					foreach($tagSettings->collections as $collectionName => $collectionValue){
						$collectionName = strtolower($collectionName);
						if(sizeof($this->$collectionName->array) > 0){
							$html .= $tabs . "\t" . '<xrtml:' . $collectionName . '>' . "\r\n";					
							foreach($this->$collectionName as $collectionItem){
								$html .= $collectionItem->toXRTML($deep + 2);
							}					
							$html .= $tabs . "\t" . '</xrtml:' . $collectionName . '>' . "\r\n";
						}
					}
				}
				
				if(isset($tagSettings->children)){
					foreach($tagSettings->children as $childName => $childValue){
						$childName = strtolower($childName);
						$html .= $tabs . $this->$childName->toXRTML($deep + 1);
					}
				}
				
				if(isset($tagSettings->content)){
					$html .= $tabs . "\t<!-- \r\n";
					$html .=$tabs ."\t\t" . $this->content . "\r\n";
					$html .= $tabs . "\t-->\r\n"; 
				}	
				$html .= $tabs . "</xrtml:$tagName>\n";
			} else {
				$html .= " />\r\n";
			}
			return $html;
		}	
		
		private function validateTag(){
			$className = get_class($this);
			$tagName = str_replace('xRTML', '', $className);
			$tagSettings = xRTMLTagFactory::getTagSettings($tagName);
			if(isset($tagSettings->attributes)){
				foreach($tagSettings->attributes as $attrName => $attrVal){
					$mandatory = (string)$attrVal->mandatory;
					if(strtolower($mandatory) == '1'){
						if(!isset($this->$attrName)){
							throw new Exception("Attribute $attrName is mandatory for the $tagName tag.");
						}
					}
					if(strtolower($attrVal->type) == 'boolean'){
						if(isset($this->attrName) && !is_bool($this->attrName)){
							if($this->attrName != 'true' && strtolower($this->attrName) != 'false'){
								throw new Exception("Attribute $attrName must be set to true or false.");
							}
						}
					} else if(isset($attrVal->possibleValues)){
						if(isset($this->$attrName)){							
							if(!in_array($this->$attrName, $attrVal->possibleValues)){
								throw new Exception("Attribute $attrName must be set to one of the following values: [" . implode(',', $attrVal->possibleValues) . ']');
							}
						}
					}
				}
			}			
		}
	}

	abstract class xRTMLTagFactory{
		private static $jsonConfigString = '{"Tags":{"Tag":{"abstract":true,"attributes":{"id":{"mandatory":false,"type":"String"},"receiveownmessages":{"mandatory":false,"type":"Boolean","defaultValue":true},"active":{"mandatory":false,"type":"Boolean","defaultValue":true},"preprocess":{"mandatory":false,"type":"String"},"postprocess":{"mandatory":false,"type":"String"}}},"Config":{"attributes":{"debug":{"mandatory":false,"type":"Boolean","defaultValue":false},"loglevel":{"mandatory":false,"type":"String","defaultValue":"info","possibleValues":["info","warn","error"]},"xrtmlactive":{"mandatory":false,"type":"Boolean","defaultValue":true},"throwerrors":{"mandatory":false,"type":"Boolean","defaultValue":false},"connectionsattempts":{"mandatory":false,"type":"Number","defaultValue":"5"},"connectionstimeout":{"mandatory":false,"type":"Number"},"ortcversion":{"mandatory":false,"type":"String","defaultValue":"1.2.1_dev","possibleValues":["1.2.1","1.2.1_dev"]},"ortcservertype":{"mandatory":false,"type":"String","possibleValues":["IbtRealTimeSJ","IbtRealTimeS","IbtRealTimeK"]}},"collections":{"Connections":{}},"children":{}},"BroadCast":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"}},"collections":{"Triggers":{},"Dispatchers":{}},"children":{}},"BrowserControl":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String","defaultValue":""},"generatecontrols":{"mandatory":false,"type":"Boolean","defaultValue":false},"role":{"mandatory":true,"type":"String","possibleValues":["sender","receiver"]}},"collections":{"Triggers":{},"Elements":{}},"children":{}},"DrawingBoard":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"broadcastinterval":{"mandatory":false,"type":"Number","defaultValue":10},"role":{"mandatory":false,"type":"String","possibleValues":["sender","receiver","both"]},"width":{"mandatory":false,"type":"Number","defaultValue":320},"height":{"mandatory":false,"type":"Number","defaultValue":470},"imagessource":{"mandatory":false,"type":"String","defaultValue":"css\/img\/"},"lineWidth":{"mandatory":false,"type":"String"},"strokeStyle":{"mandatory":false,"type":"String"}},"collections":{"Triggers":{}},"children":{}},"Execute":{"extends":"Tag","attributes":{"channelid":{"mandatory":false,"type":"String","defaultValue":"The name of the channel that will be used to send messages."},"callback":{"mandatory":false,"type":"String"}},"collections":{"Triggers":{}},"children":{}},"KeyTracker":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"},"sendall":{"mandatory":false,"type":"Boolean","defaultValue":false}},"collections":{"Triggers":{}},"children":{}},"AbstractMouseTag":{"extends":"Tag","abstract":true,"attributes":{"channelid":{"mandatory":true,"type":"String","defaultValue":""},"target":{"mandatory":false,"type":"String","defaultValue":"body"},"periodicity":{"mandatory":false,"type":"Number","defaultValue":10},"centerwidth":{"mandatory":false,"type":"Boolean","defaultValue":false},"centerheight":{"mandatory":false,"type":"Boolean","defaultValue":false},"offsetx":{"mandatory":false,"type":"Number","defaultValue":0},"offsety":{"mandatory":false,"type":"Number","defaultValue":0}},"collections":{"Triggers":{}},"children":{}},"MouseLive":{"extends":"AbstractMouseTag","attributes":{"role":{"mandatory":true,"type":"String","possibleValues":["sender","receiver"],"defaultValue":""}},"children":{},"collections":{}},"MouseTracker":{"extends":"AbstractMouseTag","attributes":{},"children":{},"collections":{}},"Placeholder":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"}},"collections":{"Triggers":{}},"children":{"Template":{}}},"Poll":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"receiveownmessages":{"mandatory":false,"type":"Boolean","defaultValue":true},"target":{"mandatory":false,"type":"String"},"getdataurl":{"mandatory":true,"type":"String"},"voteurl":{"mandatory":false,"type":"String","defaultValue":"The path to the handler that will update the data to a database."}},"collections":{"Triggers":{},"JQueryEffects":{}},"children":{}},"Chart":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String","defaultValue":""},"chartingplatform":{"mandatory":true,"type":"String","possibleValues":["HTML","Highcharts"],"defaultValue":""},"configfunction":{"mandatory":false,"type":"String","defaultValue":"Default Option"},"getdataurl":{"mandatory":true,"type":"String","defaultValue":""},"target":{"mandatory":false,"type":"String","defaultValue":""}},"children":{},"collections":{"dataitems":{},"triggers":{},"jqueryeffects":{}}},"Repeater":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"},"index":{"mandatory":false,"type":"String","defaultValue":"end"},"removeindex":{"mandatory":false,"type":"String","defaultValue":"end"},"maxitens":{"mandatory":false,"type":"Number"},"datakeyname":{"mandatory":false,"type":"String"}},"collections":{"Triggers":{},"JQueryEffects":{}},"children":{"Template":{}}},"TextToSpeech":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"message":{"mandatory":false,"type":"String"},"amplitude":{"mandatory":false,"type":"Number","defaultValue":100},"wordgap":{"mandatory":false,"type":"Number","defaultValue":"0"},"pitch":{"mandatory":false,"type":"Number","defaultValue":"50"},"speed":{"mandatory":false,"type":"Number","defaultValue":"175"}},"collections":{"Triggers":{}},"children":{}},"VideoChat":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"},"generatehtml":{"mandatory":false,"type":"Boolean"},"apikey":{"mandatory":true,"type":"String"},"sessionid":{"mandatory":true,"type":"String"},"token":{"mandatory":true,"type":"String"},"persist":{"mandatory":false,"type":"Boolean","defaultValue":true}},"collections":{"Triggers":{},"Elements":{}},"children":{}},"VisitorCounter":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"}},"collections":{"Triggers":{}},"children":{}},"ShoutBox":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"},"historyrepository":{"mandatory":false,"type":"String"}},"collections":{"Triggers":{},"Elements":{"key":{"mandatoryValues":[]}}},"children":{},"events":{"onMessage":{},"onMessagePost":{},"onMessageHistory":{}}},"GeoLocation":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"},"errorhandler":{"mandatory":false,"type":"String"},"enablehighaccuracy":{"mandatory":false,"type":"Boolean","defaultValue":false},"timeout":{"mandatory":false,"type":"Number"},"maximumage":{"mandatory":false,"type":"Number","defaultValue":0}},"collections":{"Triggers":{}},"children":{}},"Toast":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"}},"collections":{"Triggers":{},"JQueryEffects":{}},"children":{}},"Video":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"}},"collections":{"Triggers":{}},"children":{}},"Audio":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"}},"collections":{"Triggers":{}},"children":{}},"Cloud":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"},"fontunit":{"mandatory":false,"type":"String","defaultValue":"px"},"fontsizemin":{"mandatory":false,"type":"Number","defaultValue":8},"fontsizemax":{"mandatory":false,"type":"Number","defaultValue":40},"numbertags":{"mandatory":false,"type":"Number","defaultValue":20}},"collections":{"Triggers":{}},"children":{}},"Booking":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"},"bookingitem":{"mandatory":true,"type":"String"},"userid":{"mandatory":false,"type":"String"},"useridcallback":{"mandatory":false,"type":"String"},"bookinglimit":{"mandatory":true,"type":"Number"},"handlerurl":{"mandatory":false,"type":"String"},"ondatapreload":{"mandatory":false,"type":"String"},"ondataload":{"mandatory":false,"type":"String"},"onbookingsuccess":{"mandatory":false,"type":"String"},"onbookingoverlimit":{"mandatory":false,"type":"String"},"onbookingtaken":{"mandatory":false,"type":"String"},"onbookingcancel":{"mandatory":false,"type":"String"}},"collections":{"Triggers":{}},"children":{},"events":{"ondatapreload":{},"ondataload":{},"onbookingsuccess":{},"onbookingoverlimit":{},"onbookingtaken":{},"onbookingcancel":{}}},"Calendar":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String","defaultValue":""},"target":{"mandatory":true,"type":"String","defaultValue":""},"userid":{"mandatory":false,"type":"String","defaultValue":""},"useridcallback":{"mandatory":false,"type":"String","defaultValue":""},"handlerurl":{"mandatory":true,"type":"String","defaultValue":""},"startdate":{"mandatory":false,"type":"Date (yyyy-mm-dd)","defaultValue":""},"enddate":{"mandatory":false,"type":"Date (yyyy-mm-dd)","defaultValue":""},"showdate":{"mandatory":false,"type":"Date (yyyy-mm)","defaultValue":""},"dayonly":{"mandatory":false,"type":"Boolean","defaultValue":""},"langscallback":{"mandatory":false,"type":"String","defaultValue":""},"lang":{"mandatory":false,"type":"String","defaultValue":"en"}},"children":{},"collections":{"Triggers":{},"Slots":{}}},"Map":{"extends":"Tag","attributes":{"channelid":{"mandatory":true,"type":"String"},"target":{"mandatory":false,"type":"String"},"type":{"mandatory":true,"type":"String","possibleValues":["googlemap","bingmap"]},"role":{"mandatory":true,"type":"String","possibleValues":["sender","receiver"]},"zoom":{"mandatory":false,"type":"Number","defaultValue":"3"},"latitude":{"mandatory":false,"type":"Number","defaultValue":"40"},"longitude":{"mandatory":false,"type":"Number","defaultValue":"-5"},"drawingmode":{"mandatory":false,"type":"String","defaultValue":"route","possibleValues":["polyline","route"]},"markertype":{"mandatory":false,"type":"String","defaultValue":"image","possibleValues":["polyline","image","polygon"]},"imageURL":{"mandatory":false,"type":"String"},"imageWidth":{"mandatory":false,"type":"Number"},"imageHeight":{"mandatory":false,"type":"Number"},"offsetImageWidth":{"mandatory":false,"type":"Number","defaultValue":"0"},"offsetImageHeight":{"mandatory":false,"type":"Number","defaultValue":"0"},"shadowImage":{"mandatory":false,"type":"String"},"offsetShadowImageWidth":{"mandatory":false,"type":"Number","defaultValue":"0"},"offsetShadowImageHeight":{"mandatory":false,"type":"Number","defaultValue":"0"},"strokeColor":{"mandatory":false,"type":"String"},"strokeOpacity":{"mandatory":false,"type":"Number"},"strokeWeight":{"mandatory":false,"type":"Number"},"fillColor":{"mandatory":false,"type":"String"},"fillOpacity":{"mandatory":false,"type":"Number"},"strokeColorRoute":{"mandatory":false,"type":"String"},"strokeOpacityRoute":{"mandatory":false,"type":"Number"},"strokeWeightRoute":{"mandatory":false,"type":"Number"},"infoWindow":{"mandatory":false,"type":"String"},"viewMode":{"mandatory":false,"type":"String","possibleValues":["HYBRID","ROADMAP","SATELLITE","TERRAIN","birdseye","aerial","road"]},"routeMode":{"mandatory":false,"type":"String","possibleValues":["DRIVING","WALKING"]}},"collections":{"Triggers":{}},"children":{}}},"Collections":{"Connections":{"Connection":{"attributes":{"id":{"mandatory":false,"type":"String"},"active":{"mandatory":false,"type":"Boolean","defaultValue":true},"authenticate":{"mandatory":false,"type":"Boolean"},"authenticationurl":{"mandatory":false,"type":"String","default":"handler\/AuthenticationHandler.ashx"},"appkey":{"mandatory":true,"type":"String"},"authtoken":{"mandatory":true,"type":"String"},"sendretries":{"mandatory":false,"type":"Number","default":"5"},"sendinterval":{"mandatory":false,"type":"Number","default":"1000"},"timeout":{"mandatory":false,"type":"Number","default":"Config.connectionTimeout"},"connectattemps":{"mandatory":false,"type":"Number","default":"Config.connectionAttempts"},"autoconnect":{"mandatory":false,"type":"Boolean","default":true},"metadata":{"mandatory":false,"type":"String"},"servertype":{"mandatory":false,"type":"String","default":"IbtRealTimeSJ"},"url":{"mandatory":false,"type":"String","default":"Config.getORTCServer()"},"messageadapter":{"mandatory":false,"type":"Function"},"oncreated":{"mandatory":false,"type":"String"},"onconnected":{"mandatory":false,"type":"String"},"ondisconnected":{"mandatory":false,"type":"String"},"onsubscribed":{"mandatory":false,"type":"String"},"onunsubscribed":{"mandatory":false,"type":"String"},"onexception":{"mandatory":false,"type":"String"},"onreconnected":{"mandatory":false,"type":"String"},"onreconnecting":{"mandatory":false,"type":"String"},"onmessage":{"mandatory":false,"type":"String"}},"collections":{"Channels":{}}}},"Channels":{"Channel":{"attributes":{"name":{"mandatory":true,"type":"String","minSize":1},"permission":{"mandatory":true,"type":"String","possibleValues":["read","write"]},"subscribeonreconnect":{"mandatory":false,"type":"String","minSize":1},"subscribe":{"mandatory":false,"type":"String","minSize":1},"onmessage":{"mandatory":false,"type":"String","minSize":1},"messageadapter":{"mandatory":false,"type":"String","minSize":1}}}},"Triggers":{"Trigger":{"attributes":{"name":{"mandatory":true,"type":"String","minSize":1}},"collections":{"Mappings":{}}}},"Mappings":{"Mapping":{"attributes":{"action":{"mandatory":true,"type":"String","minSize":1},"to":{"mandatory":true,"type":"String","minSize":1}}}},"Dispatchers":{"Dispatcher":{"attributes":{"id":{"mandatory":false,"type":"String","minSize":1},"event":{"mandatory":false,"type":"String","minSize":15},"callback":{"mandatory":false,"type":"String","minSize":100},"message":{"mandatory":false,"type":"String","minSize":500},"target":{"mandatory":false,"type":"String","minSize":100},"timeout":{"mandatory":false,"type":"Number","minSize":10,"defaultValue":0},"interval":{"mandatory":false,"type":"Number","minSize":10},"limit":{"mandatory":false,"type":"Number","minSize":100,"defaultValue":0}}}},"JQueryEffects":{"JQueryEffect":{"attributes":{"id":{"mandatory":false,"type":"String","maxOccurs":50,"minSize":1},"name":{"mandatory":false,"type":"String"},"properties":{"mandatory":false,"type":"String"},"option":{"mandatory":false,"type":"String"},"target":{"mandatory":false,"type":"String"}}}},"Elements":{"Element":{"attributes":{"key":{"mandatory":true,"type":"String","minSize":1},"value":{"mandatory":true,"type":"String"}}}},"Dataitems":{"Dataitem":{"attributes":{"name":{"mandatory":false,"type":"String","maxOccurs":50,"minSize":1},"value":{"mandatory":false,"type":"Number"}}}},"Slots":{"Slot":{"attributes":{"year":{"mandatory":false,"type":"String","minSize":1},"month":{"mandatory":false,"type":"String","minSize":1},"day":{"mandatory":false,"type":"String","minSize":1},"weekday":{"mandatory":false,"type":"String","minSize":1,"possibleValues":["Mon","Tue","Wed","Thu","Fri","Sat"]},"value":{"mandatory":false,"type":"String","minSize":1}}}}},"Children":{"Template":{"content":{"mandatory":true,"type":"LargeString","maxOccurs":1},"attributes":{}}}}';
		public static $tagsArray;
		public static $collectionsArray;
		public static $childrenArray;
		
		public static function createTagsArray(){
			$jsonObject = json_decode(self::$jsonConfigString);
			self::$tagsArray = array();
			self::$collectionsArray = array();
			self::$childrenArray = array();
			foreach($jsonObject->Tags as $tagName => $tagObject){
				self::$tagsArray[strtolower($tagName)] = $tagObject;
			}
			foreach($jsonObject->Collections as $collectionName => $collectionObject){
				foreach($collectionObject as $name => $object){
					$attrName = strtolower($name);
					self::$collectionsArray[$attrName] = $collectionObject->$name;
				}
			}
			foreach($jsonObject->Children as $childName => $childObject){
				self::$childrenArray[strtolower($childName)] = $childObject;
			}
		}
	
		public static function createTag($tagName){			
			$tagSettings = self::getTagSettings($tagName);			
			
			if(isset($tagSettings->abstract) && $tagSettings->abstract){
				throw new Exception($tagName . " is an abstract tag, cannot be instantiated");
			}
			$className = 'xRTML' . $tagName;			
			if(!class_exists($className)){
				eval('class '. $className .' extends xRTMLBaseTag { public function __construct($tagSettings){parent::__construct($tagSettings); } }');				
			}
			return new $className($tagSettings);
		}
		
		public static function getTagSettings($tagName){
			$name = strtolower($tagName);
			if(array_key_exists($name, self::$tagsArray)){
				$tagSettings = self::$tagsArray[$name];				
				if(isset($tagSettings->extends)){
					$parentSettings = self::getTagSettings($tagSettings->extends);
					if(isset($parentSettings->attributes)){
						if(!isset($tagSettings->attributes)){
							$tagSettings->attributes = new stdClass();
						}
						foreach($parentSettings->attributes as $attributeName => $attributeValue){
							$tagSettings->attributes->$attributeName = $attributeValue;
						}
					}
					if(isset($parentSettings->collections)){
						if(!isset($tagSettings->collections)){
							$tagSettings->collections = new stdClass();
						}
						foreach($parentSettings->collections as $collectionName => $collectionValue){
							$tagSettings->collections->$collectionName = $collectionValue;
						}
					}
					if(isset($parentSettings->children)){
						if(!isset($tagSettings->children)){
							$tagSettings->children = new stdClass();
						}
						foreach($parentSettings->children as $childName => $childValue){
							$tagSettings->children->$childName = $childValue;
						}
					}
					if(isset($parentSettings->events)){
						if(!isset($tagSettings->events)){
							$tagSettings->events = new stdClass();
						}
						foreach($parentSettings->events as $eventName => $eventValue){
							$tagSettings->events->$eventName = $eventValue;
						}
					}
				}
				return $tagSettings;
			}			
			if(array_key_exists($name, self::$collectionsArray)){
				return self::$collectionsArray[$name];
			}
			if(array_key_exists($name, self::$childrenArray)){
				return self::$childrenArray[$name];
			}
			return false;
		}		
	}
	
	class xRTMLArray implements IteratorAggregate{
		public $className;
		public $array;
		public static $identifiers = array('id', 'name', 'key', 'action');
		
		public function __construct($className){
			$this->className = $className;
			$this->array = array();
		}
		
		public function add($name = null){			
			$object = xRTMLTagFactory::createTag($this->className);
			if(isset($name)){
				$tagSettings = xRTMLTagFactory::getTagSettings($this->className);
				foreach(self::$identifiers as $identifier){					
					if(isset($tagSettings->attributes->$identifier)){
						$object->$identifier = $name;
						break;
					}
				}				
			}
			array_push($this->array, $object);
			return $object;
		}
		
		public function remove($item){
			if(is_object($item)){
				foreach($this->array as $arrayItem){
					if($item === $arrayItem){						
						return sizeof(array_splice($this->array, array_search($item, $this->array, true), 1)) > 0;
					}
				}
			} else{
				$cont = 0;
				foreach($this->array as $arrayItem){
					foreach(self::$identifiers as $identifier){
						if(isset($arrayItem->$identifier) && $arrayItem->$identifier == $item){
							array_splice($this->array, $cont, 1);
							return true;
						}
					}
					$cont++;
				}
				return false;
			}
			
		}
		
		public function getIterator(){
			return new ArrayIterator($this->array);
		}
	}
	
	$xrtml = new xRTML();
	